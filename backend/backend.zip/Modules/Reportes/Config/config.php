<?php

return [
    'name' => 'Reportes'
];
