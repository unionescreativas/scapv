<?php

return [
    'name' => 'Estadisticas'
];
