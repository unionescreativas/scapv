<?php

return [
    'name' => 'Georeferenciacion'
];
