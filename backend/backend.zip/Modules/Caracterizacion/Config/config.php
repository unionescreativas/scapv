<?php

return [
    'name' => 'Caracterizacion'
];
