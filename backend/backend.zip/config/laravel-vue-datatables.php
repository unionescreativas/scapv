<?php

return [
    'models' => [
        "search_term" => "searchable",
        "order_term" => "orderable",
    ],
    "default_order_by" => "id",
];