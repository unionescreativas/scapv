<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Reportes\\Providers\\ReportesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Reportes\\Providers\\ReportesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);