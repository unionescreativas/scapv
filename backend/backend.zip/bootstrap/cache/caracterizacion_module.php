<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Caracterizacion\\Providers\\CaracterizacionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Caracterizacion\\Providers\\CaracterizacionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);