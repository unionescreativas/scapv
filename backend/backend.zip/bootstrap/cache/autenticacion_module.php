<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Autenticacion\\Providers\\AutenticacionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Autenticacion\\Providers\\AutenticacionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);