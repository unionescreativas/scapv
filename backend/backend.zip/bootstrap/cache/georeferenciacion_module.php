<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Georeferenciacion\\Providers\\GeoreferenciacionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Georeferenciacion\\Providers\\GeoreferenciacionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);