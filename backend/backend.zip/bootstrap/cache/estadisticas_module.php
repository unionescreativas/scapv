<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Estadisticas\\Providers\\EstadisticasServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Estadisticas\\Providers\\EstadisticasServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);